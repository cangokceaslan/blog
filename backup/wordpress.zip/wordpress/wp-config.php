<?php
/**
 * WordPress için taban ayar dosyası.
 *
 * Bu dosya şu ayarları içerir: MySQL ayarları, tablo öneki,
 * gizli anahtaralr ve ABSPATH. Daha fazla bilgi için
 * {@link https://codex.wordpress.org/Editing_wp-config.php wp-config.php düzenleme}
 * yardım sayfasına göz atabilirsiniz. MySQL ayarlarınızı servis sağlayıcınızdan edinebilirsiniz.
 *
 * Bu dosya kurulum sırasında wp-config.php dosyasının oluşturulabilmesi için
 * kullanılır. İsterseniz bu dosyayı kopyalayıp, ismini "wp-config.php" olarak değiştirip,
 * değerleri girerek de kullanabilirsiniz.
 *
 * @package WordPress
 */

// ** MySQL ayarları - Bu bilgileri sunucunuzdan alabilirsiniz ** //
/** WordPress için kullanılacak veritabanının adı */
define( 'DB_NAME', 'cangokceaslan' );

/** MySQL veritabanı kullanıcısı */
define( 'DB_USER', 'root' );

/** MySQL veritabanı parolası */
define( 'DB_PASSWORD', '' );

/** MySQL sunucusu */
define( 'DB_HOST', 'localhost' );

/** Yaratılacak tablolar için veritabanı karakter seti. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Veritabanı karşılaştırma tipi. Herhangi bir şüpheniz varsa bu değeri değiştirmeyin. */
define('DB_COLLATE', '');

/**#@+
 * Eşsiz doğrulama anahtarları.
 *
 * Her anahtar farklı bir karakter kümesi olmalı!
 * {@link http://api.wordpress.org/secret-key/1.1/salt WordPress.org secret-key service} servisini kullanarak yaratabilirsiniz.
 * Çerezleri geçersiz kılmak için istediğiniz zaman bu değerleri değiştirebilirsiniz. Bu tüm kullanıcıların tekrar giriş yapmasını gerektirecektir.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '%jz1Ir{5yWw.D:0VxPkel+av=hnPdHbmW7(`z)+A8V@&po-=&Ds ?d];q=u3;! $' );
define( 'SECURE_AUTH_KEY',  'ElVwyyR+zPZUktfu8M<)V)jT/6.U,AYvjP)H^v1j2=dV/BQ%{!27AW[hhs l/>;%' );
define( 'LOGGED_IN_KEY',    '053|4!gEaKh/|UPMa)(TF6=}+kQTkv7?[mFKsoedp3YHyOO)Pxu:{zJA;f|<GREg' );
define( 'NONCE_KEY',        'c~Q3F0~uXek3GlPOCC5%O6&I&)|3DbterODK}>+Bh([/k,8mqSOfCTF}D~f~(32G' );
define( 'AUTH_SALT',        'G*:Ki&7#NblVz9>T)TxP4T&9dAPYh2YQ/Nx>+df]D/d;Qz##e{0s9#lY)-/kjkn,' );
define( 'SECURE_AUTH_SALT', 'AWQ:NZde)$D<P|JFE=jz-*9k+4qP|#RJ:)P!u6$(.H&(U#01Qem~9XCC,Gus{z|k' );
define( 'LOGGED_IN_SALT',   ';06UAclfOUK$BF8E #=<zTl/]nZDi97STAy@xox?W~{4|gERoFqtjvA=UFNt%nhP' );
define( 'NONCE_SALT',       'p(d(dvy59r[-fsZ|@V$c{VA;6<-GTuI]5Qn=>b>6+_!2=*a[Moh8%Q{IqHv&vh{s' );
/**#@-*/

/**
 * WordPress veritabanı tablo ön eki.
 *
 * Tüm kurulumlara ayrı bir önek vererek bir veritabanına birden fazla kurulum yapabilirsiniz.
 * Sadece rakamlar, harfler ve alt çizgi lütfen.
 */
$table_prefix = 'wp_';

/**
 * Geliştiriciler için: WordPress hata ayıklama modu.
 *
 * Bu değeri "true" yaparak geliştirme sırasında hataların ekrana basılmasını sağlayabilirsiniz.
 * Tema ve eklenti geliştiricilerinin geliştirme aşamasında WP_DEBUG
 * kullanmalarını önemle tavsiye ederiz.
 */
define('WP_DEBUG', false);

/* Hepsi bu kadar. Mutlu bloglamalar! */

/** WordPress dizini için mutlak yol. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** WordPress değişkenlerini ve yollarını kurar. */
require_once(ABSPATH . 'wp-settings.php');
